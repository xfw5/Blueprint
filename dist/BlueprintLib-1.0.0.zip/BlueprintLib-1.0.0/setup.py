from distutils.core import setup

setup (
	name = 'BlueprintLib',
	version = '1.0.0',
	py_modules = ['Blueprint'],
	author = 'xfw',
	author_email = 'xfw5@163.com',
	description = 'Blueprint lib for stock security visual coding',
	url =  'http://mei you wang zhu.com'
)